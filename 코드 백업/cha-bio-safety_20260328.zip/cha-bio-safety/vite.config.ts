import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: '차바이오컴플렉스 방재',
        short_name: '방재관리',
        description: '차바이오컴플렉스 소방안전 통합관리',
        theme_color: '#161b22',
        background_color: '#0d1117',
        display: 'fullscreen',
        orientation: 'portrait',
        start_url: '/',
        icons: [
          { src:'/icon-192.png', sizes:'192x192', type:'image/png' },
          { src:'/icon-512.png', sizes:'512x512', type:'image/png', purpose:'any maskable' },
        ],
      },
      workbox: {
        skipWaiting: true,
        clientsClaim: true,
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        runtimeCaching: [{
          urlPattern: ({ request }) => request.method === 'GET' && /\/api\//.test(request.url),
          handler: 'NetworkFirst',
          options: { cacheName:'api-cache', expiration:{ maxEntries:50, maxAgeSeconds:300 } },
        }],
      },
    }),
  ],
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:8788' },
  },
})
