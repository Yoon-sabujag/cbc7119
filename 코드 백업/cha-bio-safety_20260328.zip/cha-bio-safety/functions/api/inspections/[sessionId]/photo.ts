import type { Env } from '../../../_middleware'

// PATCH /api/inspections/:sessionId/photo
// 세션 대표 사진 key 저장
export const onRequestPut: PagesFunction<Env> = async ({ request, env, params }) => {
  const { sessionId } = params as { sessionId: string }
  const { photoKey } = await request.json<{ photoKey: string }>()

  if (!photoKey) return Response.json({ success: false, error: 'photoKey 없음' }, { status: 400 })

  await env.DB.prepare(
    `UPDATE inspection_sessions SET photo_key=? WHERE id=?`
  ).bind(photoKey, sessionId).run()

  return Response.json({ success: true })
}
