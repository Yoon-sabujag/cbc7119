import type { Env } from '../../../../_middleware'

// POST /api/inspections/records/:recordId/resolve
// 불량/주의 점검 기록을 조치 완료 처리
export const onRequestPost: PagesFunction<Env> = async ({ request, env, data, params }) => {
  const { staffId } = data as any
  const { recordId } = params as { recordId: string }
  const { resolution_memo, resolution_photo_key } = await request.json<{ resolution_memo?: string; resolution_photo_key?: string }>()

  const record = await env.DB.prepare(
    `SELECT id, result FROM check_records WHERE id = ? LIMIT 1`
  ).bind(recordId).first<{ id: string; result: string }>()

  if (!record) return Response.json({ success: false, error: '기록 없음' }, { status: 404 })

  await env.DB.prepare(`
    UPDATE check_records
    SET status='resolved', resolution_memo=?, resolution_photo_key=?, resolved_at=datetime('now'), resolved_by=?
    WHERE id=?
  `).bind(resolution_memo ?? null, resolution_photo_key ?? null, staffId, recordId).run()

  return Response.json({ success: true, data: { resolved: true } })
}
