import type { Env } from '../../_middleware'

// GET /api/inspections/records?date=YYYY-MM-DD
// 해당 날짜의 전체 직원 점검 기록을 반환 (checkpoint_id 기준 최신 1건)
export const onRequestGet: PagesFunction<Env> = async ({ request, env }) => {
  const url  = new URL(request.url)
  const date = url.searchParams.get('date') ?? new Date().toISOString().slice(0, 10)

  const result = await env.DB.prepare(`
    SELECT r.id, r.checkpoint_id, r.result, r.memo, r.photo_key, r.staff_id, r.checked_at,
           r.status, r.resolution_memo, r.resolution_photo_key, r.resolved_at, r.resolved_by
    FROM check_records r
    JOIN inspection_sessions s ON s.id = r.session_id
    WHERE s.date = ?
    ORDER BY r.checked_at DESC
  `).bind(date).all<Record<string,unknown>>()

  // checkpoint_id 기준 최신 1건만 유지
  const seen = new Set<string>()
  const rows = (result.results ?? []).filter(r => {
    const cpId = r.checkpoint_id as string
    if (seen.has(cpId)) return false
    seen.add(cpId)
    return true
  }).map(r => ({
    id:                 r.id,
    checkpointId:       r.checkpoint_id,
    result:             r.result,
    memo:               r.memo,
    photoKey:           r.photo_key,
    staffId:            r.staff_id,
    checkedAt:          r.checked_at,
    status:             r.status ?? 'open',
    resolutionMemo:     r.resolution_memo,
    resolutionPhotoKey: r.resolution_photo_key,
    resolvedAt:         r.resolved_at,
    resolvedBy:         r.resolved_by,
  }))

  return Response.json({ success: true, data: rows })
}
