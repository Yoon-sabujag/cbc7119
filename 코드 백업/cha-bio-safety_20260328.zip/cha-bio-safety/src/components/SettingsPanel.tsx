import { useState } from 'react'

const NAV_H = 'calc(54px + var(--sab, 0px))'

interface Props {
  open: boolean
  onClose: () => void
}

function Toggle({ defaultOn = true }: { defaultOn?: boolean }) {
  const [on, setOn] = useState(defaultOn)
  return (
    <button
      onClick={() => setOn(v => !v)}
      style={{
        width:38, height:21, borderRadius:11, border:'none', cursor:'pointer',
        background: on ? '#2563eb' : 'var(--bg4)',
        position:'relative', transition:'background 0.18s', flexShrink:0,
      }}
    >
      <span style={{
        position:'absolute', top:2, left:2, width:17, height:17, borderRadius:'50%',
        background:'#fff', transition:'transform 0.18s',
        transform: on ? 'translateX(17px)' : 'translateX(0)',
        display:'block',
      }} />
    </button>
  )
}

function Row({ label, sub, children }: { label: string; sub?: string; children: React.ReactNode }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 12px', background:'var(--bg3)', borderRadius:9, marginBottom:5 }}>
      <div>
        <div style={{ fontSize:12, fontWeight:500 }}>{label}</div>
        {sub && <div style={{ fontSize:10, color:'var(--t3)', marginTop:1 }}>{sub}</div>}
      </div>
      {children}
    </div>
  )
}

export function SettingsPanel({ open, onClose }: Props) {
  return (
    <>
      <div
        onClick={onClose}
        style={{
          position:'fixed', inset:0, zIndex:190,
          background:'rgba(0,0,0,0.65)',
          opacity: open ? 1 : 0,
          pointerEvents: open ? 'all' : 'none',
          transition:'opacity 0.28s',
        }}
      />
      <div
        style={{
          position:'fixed', top:0, bottom:0, right:0, zIndex:200,
          width:'88%', maxWidth:320,
          background:'var(--bg2)',
          transform: open ? 'translateX(0)' : 'translateX(100%)',
          transition:'transform 0.3s cubic-bezier(.4,0,.2,1)',
          overflowY:'auto',
        }}
      >
        {/* 헤더 */}
        <div style={{ display:'flex', alignItems:'center', gap:10, padding:'calc(15px + var(--sat, 0px)) 15px 12px', borderBottom:'1px solid var(--bd)', flexShrink:0 }}>
          <svg width={16} height={16} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
          <span style={{ fontSize:13.5, fontWeight:700 }}>설정</span>
          <button onClick={onClose} style={{ marginLeft:'auto', width:28, height:28, borderRadius:7, background:'var(--bg3)', border:'none', color:'var(--t2)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15 }}>✕</button>
        </div>

        <div style={{ padding:'12px 13px 5px' }}>
          <div style={{ fontSize:9, fontWeight:700, color:'var(--t3)', letterSpacing:'.08em', textTransform:'uppercase', marginBottom:6 }}>알림</div>
          <Row label="점검 미완료 알림" sub="마감 1시간 전"><Toggle defaultOn /></Row>
          <Row label="미조치 항목 알림" sub="매일 09:00"><Toggle defaultOn /></Row>
          <Row label="승강기 점검 D-7 알림"><Toggle defaultOn={false} /></Row>
        </div>

        <div style={{ padding:'12px 13px 5px' }}>
          <div style={{ fontSize:9, fontWeight:700, color:'var(--t3)', letterSpacing:'.08em', textTransform:'uppercase', marginBottom:6 }}>화면</div>
          <Row label="테마">
            <select style={{ background:'var(--bg4)', border:'1px solid var(--bd2)', color:'var(--t1)', fontSize:11, padding:'4px 7px', borderRadius:7, outline:'none' }}>
              <option>다크</option><option>라이트</option><option>시스템</option>
            </select>
          </Row>
          <Row label="주간 현황 기준">
            <select style={{ background:'var(--bg4)', border:'1px solid var(--bd2)', color:'var(--t1)', fontSize:11, padding:'4px 7px', borderRadius:7, outline:'none' }}>
              <option>이번 주</option><option>최근 7일</option>
            </select>
          </Row>
          <Row label="결과 즉시 저장"><Toggle defaultOn /></Row>
        </div>

        <div style={{ padding:'12px 13px 5px' }}>
          <div style={{ fontSize:9, fontWeight:700, color:'var(--t3)', letterSpacing:'.08em', textTransform:'uppercase', marginBottom:6 }}>계정</div>
          <Row label="비밀번호 변경">
            <svg width={13} height={13} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7"/></svg>
          </Row>
        </div>

        <div style={{ padding:13, textAlign:'center' }}>
          <div style={{ fontSize:10, color:'var(--t3)' }}>차바이오컴플렉스 방재 v1.0.0</div>
          <div style={{ fontSize:9, color:'var(--t3)', marginTop:2 }}>경기도 성남시 분당구 판교로 335</div>
        </div>
      </div>
    </>
  )
}
